import numpy as np
import plotly.graph_objs as go
from plotly.subplots import make_subplots

def streamline(*,x,y,z=None,u,v,w=None,xi,yi,zi=None,n,length,r_mag=False,r_u=False,r_v=False,r_w=False):
    '''
    #   Made on 23 / 07 / 2020 (dd / mm / yyyy)
    #   Made this referring the "streamline" function of MATLAB 2018a
    #   modules to install "numpy, scipy"
    #    x,y,z,u,v,w = given vector data (u,v,w) for corresponding (x,y,z)
    #       x,y,z,u,v,w should be 3d numpy array ( for 3d streamline )
    #       x,y,z should be grided as "[y,x,z]=numpy.meshgrid(y,x,z)"
    #                                      OR
    #       x,y,u,v should be 2d numpy array ( for 2d streamline )
    #       x,y should be grided as "[y,x]=numpy.meshgrid(y,x)"
    #   xi = initial x values as a row i.e. 1d row numpy array
    #   yi = initial y values as a row i.e. 1d row numpy array
    #   zi = initial z values as a row i.e. 1d row numpy array
    #   n = total number of lines = total number of points (excluding initial point)
    #   length = length of each line = distance between consecutive points
    #   r_mag(return magnitude) = whether to return magnitude of vectors or not       |   all these
    #   r_u(return u) = whether to return i_cap(x component) of vectors or not          | are useful
    #   r_v(return v) = whether to return j_cap(y component) of vectors or not          |  for
    #   r_w(return w) = whether to return k_cap(z component) of vectors or not        |   gradient plotting (i.e. useful to color the lines based on these values)
    #   returns in the following format:
    #       [xo,yo,zo,(mag),(i_cap),(j_cap),(k_cap)]
    #           mag is returned if r_mag==True
    #           i_cap is returned if r_u==True
    #           j_cap is returned if r_v==True
    #           k_cap is returned if r_w==True
    #       xo, yo,zo,mag,i_cap,j_cap,k_cap have same dimensions i.e. array shape = (xi.shape,n+1)
    '''
    
    from scipy.interpolate import interpn
    import numpy as np

    if np.all(z!=None) and z[0,0,:].shape[0]>1: # 3d streamline
        
        xo=np.zeros([xi.shape[-1],n+1])
        yo=np.zeros([yi.shape[-1],n+1])
        zo=np.zeros([zi.shape[-1],n+1])
        if r_mag==True: mag=np.zeros([xi.shape[-1],n+1])
        if r_u==True: i_cap=np.zeros([xi.shape[-1],n+1])
        if r_v==True: j_cap=np.zeros([xi.shape[-1],n+1])
        if r_w==True: k_cap=np.zeros([xi.shape[-1],n+1])

        xo[:,0]=xi
        yo[:,0]=yi
        zo[:,0]=zi

        for j in np.arange(xi.shape[-1]):
            for i in np.arange(n):
                
                a=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),u,[xo[j,i],yo[j,i],zo[j,i]],bounds_error=False)
                b=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),v,[xo[j,i],yo[j,i],zo[j,i]],bounds_error=False)
                c=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),w,[xo[j,i],yo[j,i],zo[j,i]],bounds_error=False)

                if r_mag==True: mag[j,i]=(a**2+b**2+c**2)**(1/2)
                if r_u==True: i_cap[j,i]=a
                if r_v==True: j_cap[j,i]=b
                if r_w==True: k_cap[j,i]=c

                xo[j,i+1]=xo[j,i]+(a*length)/((a**2+b**2+c**2)**(1/2))
                yo[j,i+1]=yo[j,i]+(b*length)/((a**2+b**2+c**2)**(1/2))
                zo[j,i+1]=zo[j,i]+(c*length)/((a**2+b**2+c**2)**(1/2))
            
            a=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),u,[xo[j,n],yo[j,n],zo[j,n]],bounds_error=False)
            b=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),v,[xo[j,n],yo[j,n],zo[j,n]],bounds_error=False)
            c=interpn((x[:,0,0],y[0,:,0],z[0,0,:]),w,[xo[j,n],yo[j,n],zo[j,n]],bounds_error=False)

            if r_mag==True: mag[j,n]=(a**2+b**2+c**2)**(1/2)
            if r_u==True: i_cap[j,n]=a
            if r_v==True: j_cap[j,n]=b
            if r_w==True: k_cap[j,n]=c

        ret=[xo,yo,zo]
        if r_mag==True: ret.append(mag)
        if r_u==True: ret.append(i_cap)
        if r_v==True: ret.append(j_cap)
        if r_w==True: ret.append(k_cap)
        
        return ret
    
    else: # 2d streamline
        
        del zi # removing unnecessary variable
        if np.all(z!=None) and z[0,0,:].shape[0]==1: x=x[:,:,0]; y=y[:,:,0]; u=u[:,:,0]; v=v[:,:,0];
        
        xo=np.zeros([xi.shape[-1],n+1])
        yo=np.zeros([yi.shape[-1],n+1])
        if r_mag==True: mag=np.zeros([xi.shape[-1],n+1])
        if r_u==True: i_cap=np.zeros([xi.shape[-1],n+1])
        if r_v==True: j_cap=np.zeros([xi.shape[-1],n+1])

        xo[:,0]=xi
        yo[:,0]=yi

        for j in np.arange(xi.shape[-1]):
            for i in np.arange(n):
                
                a=interpn((x[:,0],y[0,:]),u,[xo[j,i],yo[j,i]],bounds_error=False)
                b=interpn((x[:,0],y[0,:]),v,[xo[j,i],yo[j,i]],bounds_error=False)

                if r_mag==True: mag[j,i]=(a**2+b**2+c**2)**(1/2)
                if r_u==True: i_cap[j,i]=a
                if r_v==True: j_cap[j,i]=b

                xo[j,i+1]=xo[j,i]+(a*length)/((a**2+b**2)**(1/2))
                yo[j,i+1]=yo[j,i]+(b*length)/((a**2+b**2)**(1/2))
            
            a=interpn((x[:,0],y[0,:]),u,[xo[j,n],yo[j,n]],bounds_error=False)
            b=interpn((x[:,0],y[0,:]),v,[xo[j,n],yo[j,n]],bounds_error=False)

            if r_mag==True: mag[j,n]=(a**2+b**2)**(1/2)
            if r_u==True: i_cap[j,n]=a
            if r_v==True: j_cap[j,n]=b

        ret=[xo,yo]
        if r_mag==True: ret.append(mag)
        if r_u==True: ret.append(i_cap)
        if r_v==True: ret.append(j_cap)
        
        return ret


fig = make_subplots(rows=1, cols=2,
    specs=[[dict(type='scatter3d'),dict(type='scatter3d')]]
                    )

e_o=8.854*10**-12
e_r=1
e=e_o*e_r

###########       like charges               ############
x=np.arange(-10,11)+0.01
y=np.arange(-10,11)+0.01
z=np.arange(-10,11)+0.01
y,x,z=np.meshgrid(y,x,z)
#  1  #######
Q1=1
sx1=-5
sy1=0
sz1=0
u1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((x-sx1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))
v1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((y-sy1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))
w1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((z-sz1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))

#  2  ########
Q2=1
sx2=5
sy2=0
sz2=0
u2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((x-sx2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))
v2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((y-sy2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))
w2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((z-sz2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))

##########

u=u1+u2
v=v1+v2
w=w1+w2

theta=np.linspace(0,2*np.pi,50)
phi=np.linspace(0,2*np.pi,50)
[theta,phi]=np.meshgrid(theta,phi)
r=np.zeros(theta.shape)+0.5
xi=r*np.sin(theta)*np.cos(phi)-5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(theta)
fig.add_trace(go.Surface(x=xi,y=yi,z=zi,showscale=False),row=1,col=1)

r=np.array([1.5])
theta=np.linspace(0,2*np.pi,10)
phi=np.linspace(0,np.pi,10)
r,theta,phi=np.meshgrid(r,theta,phi)
xi=r*np.cos(theta)*np.sin(phi)-5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(phi)
xi=xi.flatten()
yi=yi.flatten()
zi=zi.flatten()
xo,yo,zo,mag,i_cap,j_cap,k_cap=streamline(x=x,y=y,z=z,u=u,v=v,w=w,xi=xi,yi=yi,zi=zi,n=100,length=0.1,r_mag=True,r_u=True,r_v=True,r_w=True)

for i in range(xo.shape[0]):
    fig.add_trace(go.Scatter3d(x=xo[i].flatten(),y=yo[i].flatten(),z=zo[i].flatten(),mode='lines',showlegend=False,line=dict(color=mag[i],width=2,cmin=np.nanmin(mag),cmax=np.nanmax(mag))),row=1,col=1)
fig.add_trace(go.Cone(x=xo.flatten(),y=yo.flatten(),z=zo.flatten(),u=i_cap.flatten(),v=j_cap.flatten(),w=k_cap.flatten(),anchor='tip',sizeref=2,colorbar=dict(showticklabels=True,x=-0.1)),row=1,col=1)

theta=np.linspace(0,2*np.pi,50)
phi=np.linspace(0,2*np.pi,50)
[theta,phi]=np.meshgrid(theta,phi)
r=np.zeros(theta.shape)+0.5
xi=r*np.sin(theta)*np.cos(phi)+5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(theta)
fig.add_trace(go.Surface(x=xi,y=yi,z=zi,showscale=False),row=1,col=1)

r=np.array([1.5])
theta=np.linspace(0,2*np.pi,10)
phi=np.linspace(0,np.pi,10)
r,theta,phi=np.meshgrid(r,theta,phi)
xi=r*np.cos(theta)*np.sin(phi)+5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(phi)
xi=xi.flatten()
yi=yi.flatten()
zi=zi.flatten()
xo,yo,zo,mag,i_cap,j_cap,k_cap=streamline(x=x,y=y,z=z,u=u,v=v,w=w,xi=xi,yi=yi,zi=zi,n=100,length=0.1,r_mag=True,r_u=True,r_v=True,r_w=True)

for i in range(xo.shape[0]):
    fig.add_trace(go.Scatter3d(x=xo[i].flatten(),y=yo[i].flatten(),z=zo[i].flatten(),mode='lines',showlegend=False,line=dict(color=mag[i],width=2,cmin=np.nanmin(mag),cmax=np.nanmax(mag))),row=1,col=1)
fig.add_trace(go.Cone(x=xo.flatten(),y=yo.flatten(),z=zo.flatten(),u=i_cap.flatten(),v=j_cap.flatten(),w=k_cap.flatten(),anchor='tip',sizeref=2,colorbar=dict(showticklabels=False,x=-0.1)),row=1,col=1)




###########       unlike charges               ############
x=np.arange(-10,11)+0.01
y=np.arange(-10,11)+0.01
z=np.arange(-10,11)+0.01
y,x,z=np.meshgrid(y,x,z)
#  1  #######
Q1=1
sx1=-5
sy1=0
sz1=0
u1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((x-sx1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))
v1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((y-sy1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))
w1=(Q1/(4*np.pi*e*((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)))*((z-sz1)/(((x-sx1)**2+(y-sy1)**2+(z-sz1)**2)**(1/2)))

#  2  ########
Q2=-1
sx2=5
sy2=0
sz2=0
u2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((x-sx2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))
v2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((y-sy2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))
w2=(Q2/(4*np.pi*e*((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)))*((z-sz2)/(((x-sx2)**2+(y-sy2)**2+(z-sz2)**2)**(1/2)))

##########

u=u1+u2
v=v1+v2
w=w1+w2

theta=np.linspace(0,2*np.pi,50)
phi=np.linspace(0,2*np.pi,50)
[theta,phi]=np.meshgrid(theta,phi)
r=np.zeros(theta.shape)+0.5
xi=r*np.sin(theta)*np.cos(phi)-5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(theta)
fig.add_trace(go.Surface(x=xi,y=yi,z=zi,showscale=False),row=1,col=2)

r=np.array([1.5])
theta=np.linspace(0,2*np.pi,10)
phi=np.linspace(0,np.pi,10)
r,theta,phi=np.meshgrid(r,theta,phi)
xi=r*np.cos(theta)*np.sin(phi)-5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(phi)
xi=xi.flatten()
yi=yi.flatten()
zi=zi.flatten()
xo,yo,zo,mag,i_cap,j_cap,k_cap=streamline(x=x,y=y,z=z,u=u,v=v,w=w,xi=xi,yi=yi,zi=zi,n=200,length=0.1,r_mag=True,r_u=True,r_v=True,r_w=True)

for i in range(xo.shape[0]):
    fig.add_trace(go.Scatter3d(x=xo[i].flatten(),y=yo[i].flatten(),z=zo[i].flatten(),mode='lines',showlegend=False,line=dict(color=mag[i],width=2,cmin=np.nanmin(mag),cmax=np.nanmax(mag))),row=1,col=2)
fig.add_trace(go.Cone(x=xo.flatten(),y=yo.flatten(),z=zo.flatten(),u=i_cap.flatten(),v=j_cap.flatten(),w=k_cap.flatten(),anchor='tip',sizeref=2,colorbar=dict(showticklabels=True)),row=1,col=2)

theta=np.linspace(0,2*np.pi,50)
phi=np.linspace(0,2*np.pi,50)
[theta,phi]=np.meshgrid(theta,phi)
r=np.zeros(theta.shape)+0.5
xi=r*np.sin(theta)*np.cos(phi)+5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(theta)
fig.add_trace(go.Surface(x=xi,y=yi,z=zi,showscale=False),row=1,col=2)

r=np.array([1.5])
theta=np.linspace(0,2*np.pi,10)
phi=np.linspace(0,np.pi,10)
r,theta,phi=np.meshgrid(r,theta,phi)
xi=r*np.cos(theta)*np.sin(phi)+5
yi=r*np.sin(theta)*np.sin(phi)
zi=r*np.cos(phi)
xi=xi.flatten()
yi=yi.flatten()
zi=zi.flatten()
xo,yo,zo,mag,i_cap,j_cap,k_cap=streamline(x=x,y=y,z=z,u=-u,v=-v,w=-w,xi=xi,yi=yi,zi=zi,n=200,length=0.1,r_mag=True,r_u=True,r_v=True,r_w=True)
i_cap=-i_cap
j_cap=-j_cap
k_cap=-k_cap

for i in range(xo.shape[0]):
    fig.add_trace(go.Scatter3d(x=xo[i].flatten(),y=yo[i].flatten(),z=zo[i].flatten(),mode='lines',showlegend=False,line=dict(color=mag[i],width=2,cmin=np.nanmin(mag),cmax=np.nanmax(mag))),row=1,col=2)
fig.add_trace(go.Cone(x=xo.flatten(),y=yo.flatten(),z=zo.flatten(),u=i_cap.flatten(),v=j_cap.flatten(),w=k_cap.flatten(),anchor='tip',sizeref=2,colorbar=dict(showticklabels=False)),row=1,col=2)





fig.update_layout(title=dict(text='Electric Field Intensity of Like  and Unlike Point Charges',x=0.5),font=dict(family='Cooper Black',size=18))




fig.show()
